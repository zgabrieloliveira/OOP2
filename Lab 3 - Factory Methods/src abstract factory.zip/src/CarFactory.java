public interface CarFactory {
    Carro createCarro();
    Motor createMotor();
    Acessorio createAcessorio();
}
