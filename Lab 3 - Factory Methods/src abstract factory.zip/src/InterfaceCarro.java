public interface InterfaceCarro {
    
    void acelerar(float incremento);
    void frear(float decremento);

}
