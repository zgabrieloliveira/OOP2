public class AcessorioTesla implements Acessorio {
    
    public void multimidia() {
        System.out.println("Multimidia Tesla: Tesla IA");
    }
}
