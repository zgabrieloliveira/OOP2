public class MotorTesla implements Motor {
    
    public void ignicao() {
        System.out.println("Tesla Elétrico Tesla Ligado");
    }
}
