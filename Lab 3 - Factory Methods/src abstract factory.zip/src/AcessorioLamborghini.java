public class AcessorioLamborghini implements Acessorio {
    
    public void multimidia() {
        System.out.println("Multimidia Lamborghini: Booze");
    }
}
