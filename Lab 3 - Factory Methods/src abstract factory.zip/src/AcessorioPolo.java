public class AcessorioPolo implements Acessorio {
    
    public void multimidia() {
        System.out.println("Multimidia Polo: Beats");
    }
}
