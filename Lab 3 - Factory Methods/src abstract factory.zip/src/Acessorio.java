public interface Acessorio {
    void multimidia();
}
