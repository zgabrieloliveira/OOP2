public interface Motor {
    void ignicao();
}
