public class MotorPolo implements Motor {
    
    public void ignicao() {
        System.out.println("Polo 200 TSI Ligado");
    }

}
