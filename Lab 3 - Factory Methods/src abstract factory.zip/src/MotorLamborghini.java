public class MotorLamborghini implements Motor {
    
    public void ignicao() {
        System.out.println("Lamborghini V12 5.0 Ligado");
    }
}
